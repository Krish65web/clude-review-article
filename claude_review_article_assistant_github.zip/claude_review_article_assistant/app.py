import os, re, json
import streamlit as st
from dotenv import load_dotenv
from anthropic import Anthropic
from research import search_pubmed, search_crossref, verify_doi
from docx_export import make_docx

load_dotenv()
st.set_page_config(page_title="Claude Review Article Assistant", page_icon="📚", layout="wide")
st.title("📚 Claude Review Article Assistant")
st.caption("Evidence-grounded review drafting with PubMed/Crossref and Vancouver references.")

api_key = os.getenv("ANTHROPIC_API_KEY", "")
with st.sidebar:
    st.header("Settings")
    model = st.text_input("Claude model", value=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5"))
    max_papers = st.slider("Maximum papers to retrieve", 5, 30, 15)
    st.caption("Set ANTHROPIC_API_KEY in your .env file. Never commit API keys to GitHub.")

topic = st.text_input("Review article topic", placeholder="e.g., Co-processed excipients in direct compression")
question = st.text_area("Scope / research question", placeholder="What should this review cover? Include population, technology, outcomes, years, etc.")
years = st.text_input("Publication year range (optional)", placeholder="e.g., 2015-2026")
db = st.multiselect("Databases", ["PubMed", "Crossref"], default=["PubMed", "Crossref"])
if "papers" not in st.session_state:
    st.session_state.papers = []
if "draft" not in st.session_state:
    st.session_state.draft = ""

col1, col2 = st.columns(2)
with col1:
    if st.button("1. Search scientific literature", type="primary", disabled=not topic.strip()):
        found = []
        if "PubMed" in db:
            found += search_pubmed(topic, max_papers)
        if "Crossref" in db:
            found += search_crossref(topic, max_papers)
        # Deduplicate by DOI or normalized title
        seen, unique = set(), []
        for p in found:
            key = (p.get("doi") or p.get("title","").lower()).lower()
            if key and key not in seen:
                seen.add(key); unique.append(p)
        st.session_state.papers = unique[:max_papers*2]
        st.success(f"Retrieved {len(st.session_state.papers)} candidate records. Review and select relevant papers below.")
with col2:
    if st.button("Clear results"):
        st.session_state.papers = []
        st.session_state.draft = ""

if st.session_state.papers:
    st.subheader("2. Screen and select papers")
    selected = []
    for i, p in enumerate(st.session_state.papers):
        title = p.get("title") or "Untitled record"
        label = f"{title} ({p.get('year') or 'year n/a'})"
        if st.checkbox(label, value=True, key=f"paper_{i}"):
            selected.append(p)
        with st.expander("Record details", expanded=False):
            st.write("Authors:", p.get("authors") or "Not supplied")
            st.write("Journal:", p.get("journal") or "Not supplied")
            st.write("DOI:", p.get("doi") or "Not supplied")
            st.write("Abstract:", p.get("abstract") or "No abstract returned")
            if p.get("url"): st.link_button("Open source record", p["url"])
    st.info(f"{len(selected)} papers selected.")
    st.session_state.selected = selected

    st.subheader("3. Generate a structured review draft")
    section = st.selectbox("Draft section", [
        "Full review article outline and draft",
        "Abstract",
        "Introduction",
        "Literature review / thematic synthesis",
        "Critical discussion and research gaps",
        "Conclusion"
    ])
    tone = st.selectbox("Writing approach", ["Formal scientific academic style", "Concise academic style"])
    if st.button("Generate with Claude", type="primary", disabled=not api_key or not selected):
        client = Anthropic(api_key=api_key)
        paper_context = []
        for n, p in enumerate(selected, 1):
            paper_context.append({
                "source_number": n, "title": p.get("title"), "authors": p.get("authors"),
                "year": p.get("year"), "journal": p.get("journal"), "doi": p.get("doi"),
                "abstract": p.get("abstract"), "url": p.get("url")
            })
        prompt = f"""
You are a careful pharmaceutical sciences review-writing assistant.
Topic: {topic}
Scope/question: {question or 'Use the topic as the scope.'}
Publication years requested: {years or 'Not specified'}
Requested output: {section}
Style: {tone}

Use ONLY the supplied source records as evidence. Do not invent results, sample sizes,
methods, conclusions, DOI values, authors, journal names, or references. Abstracts are
not full texts: explicitly qualify claims when evidence comes only from abstracts.
Synthesize across studies; do not merely paraphrase one abstract at a time.
Write original, clear academic prose. Preserve scientific meaning and technical terms.
Cite factual claims with Vancouver in-text numbers [1], [2]. Assign numbers according
to the numbered source list below. Do not cite a source for a claim it does not support.
If evidence is insufficient, say so and list what full-text information is needed.
Do not claim or optimize for bypassing AI detectors. Avoid fabricated citations.
At the end, provide a "Evidence limitations and verification checklist" and a
"References" list in Vancouver style using only supplied metadata. Mark missing
bibliographic fields as [metadata unavailable] rather than guessing.

SOURCE RECORDS (numbering is fixed):
{json.dumps(paper_context, ensure_ascii=False, indent=2)}
"""
        with st.spinner("Claude is synthesizing the selected literature..."):
            msg = client.messages.create(
                model=model, max_tokens=7000,
                messages=[{"role":"user","content":prompt}]
            )
            st.session_state.draft = "".join(
                block.text for block in msg.content if getattr(block, "type", "") == "text"
            )
        st.success("Draft generated. Verify every statement against the full papers before submission.")

if st.session_state.draft:
    st.subheader("4. Review and export")
    st.warning("This is a research draft, not a verified manuscript. Check full texts, citation-to-claim fit, journal instructions, and permissions.")
    edited = st.text_area("Edit your manuscript", value=st.session_state.draft, height=520)
    st.session_state.draft = edited
    st.download_button("Download draft as Markdown", edited, file_name="review_article_draft.md")
    docx = make_docx(topic, edited)
    st.download_button("Download as Word (.docx)", docx, file_name="review_article_draft.docx",
                       mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    st.subheader("5. DOI checks")
    dois = sorted(set(re.findall(r'10\.\d{4,9}/[^\s\]]+', edited)))
    if dois:
        for doi in dois:
            ok, detail = verify_doi(doi.rstrip(".,;"))
            st.write(("✅ " if ok else "⚠️ ") + doi + " — " + detail)
    else:
        st.caption("No DOI strings detected in the draft.")

if not api_key:
    st.warning("Add ANTHROPIC_API_KEY to your local .env file, then restart the app.")
