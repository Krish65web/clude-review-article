# Claude Review Article Assistant

A starter research-writing application for pharmaceutical sciences. It discovers candidate records through PubMed and Crossref, lets the researcher screen sources, asks Claude to synthesize selected metadata/abstracts, and exports a draft to Markdown or Word.

## Important research integrity limits

- No AI detector score, including "0% AI", can be guaranteed. Do not use detector evasion as a writing objective.
- Search results and abstracts are not a substitute for reading full papers.
- The app does not currently download paywalled full text or automatically establish that every citation supports every sentence.
- Always verify each claim, reference field, DOI, retraction status, publication type, and journal requirements before submission.
- Do not upload confidential, unpublished, or restricted research data to an AI service unless your institution permits it.
- Respect database terms, publisher copyright, and institutional research-integrity policies.

## 1. Create your GitHub repository

1. Sign in to GitHub and choose **New repository**.
2. Name it `claude-review-article-assistant`.
3. Choose Private if this is your research project.
4. Add the files from this folder to the repository. You can upload files through **Add file → Upload files**, or use Git.

## 2. Get a Claude API key

1. Open https://console.anthropic.com/
2. Create an API key and configure billing if required.
3. Copy `.env.example` to a new file named `.env`.
4. Put your key after `ANTHROPIC_API_KEY=`.
5. Never commit `.env` or paste the key into source code.

The Claude chat subscription and Anthropic API billing are separate. A Claude Pro subscription does not automatically include API usage.

## 3. Run locally (Windows PowerShell)

```powershell
py -m venv .venv
.venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
streamlit run app.py
```

On macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your API key
streamlit run app.py
```

Open the local URL printed by Streamlit, usually http://localhost:8501.

## 4. Use the application

1. Enter a focused topic and scope.
2. Search PubMed and Crossref.
3. Screen the candidate records; deselect irrelevant papers.
4. Generate a section or structured draft.
5. Edit the draft and export to Word.
6. Check every DOI and verify citations against the full text.

## 5. Use the repository with Claude

In Claude, connect GitHub if that integration is available in your account, authorize access only to this repository, and ask Claude to review the code or implement a specific improvement. Alternatively, upload the repository files to a Claude Project.

Suggested Claude instruction:

> Act as a senior pharmaceutics research-methodology and Python engineering assistant. Work only with traceable scholarly sources. Never invent citations, DOI values, study findings, or bibliographic metadata. Preserve Vancouver numbering and flag any claim without evidence. Do not optimize for AI-detector evasion. Explain code changes and provide tests.

## 6. Suggested next improvements

- Add year, language, article-type and study-design filters.
- Store screening decisions and reasons for exclusion (PRISMA workflow).
- Import RIS/BibTeX from Zotero.
- Add Crossref DOI metadata reconciliation and PubMed PMID links.
- Add a citation audit screen that maps each numbered claim to a selected source.
- Add full-text import only for files the user has lawful access to, with page-level source notes.
- Add tests and a reproducible search log.

## Data sources

- PubMed / NCBI E-utilities: https://www.ncbi.nlm.nih.gov/books/NBK25501/
- Crossref REST API: https://api.crossref.org/
- Anthropic API documentation: https://docs.anthropic.com/

## Repository structure

```text
claude-review-article-assistant/
├── app.py
├── research.py
├── docx_export.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```
