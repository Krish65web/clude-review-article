from io import BytesIO
from docx import Document
from docx.shared import Inches, Pt

def make_docx(topic, markdown_text):
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.8); sec.bottom_margin = Inches(0.8)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(12)
    doc.add_heading(topic or "Review Article Draft", 0)
    for line in markdown_text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("### "): doc.add_heading(s[4:], level=3)
        elif s.startswith("## "): doc.add_heading(s[3:], level=2)
        elif s.startswith("# "): doc.add_heading(s[2:], level=1)
        elif s.startswith("- ") or s.startswith("* "): doc.add_paragraph(s[2:], style="List Bullet")
        else: doc.add_paragraph(s.replace("**","").replace("*",""))
    bio = BytesIO()
    doc.save(bio)
    return bio.getvalue()
