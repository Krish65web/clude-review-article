import requests
from xml.etree import ElementTree as ET

HEADERS = {"User-Agent": "ClaudeReviewArticleAssistant/1.0 (academic literature discovery)"}

def search_pubmed(query, limit=15):
    """Search PubMed and fetch citation metadata/abstracts through NCBI E-utilities."""
    out = []
    try:
        r = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
                         params={"db":"pubmed","term":query,"retmax":limit,"retmode":"json"},
                         headers=HEADERS, timeout=25)
        r.raise_for_status()
        ids = r.json().get("esearchresult", {}).get("idlist", [])
        if not ids: return out
        f = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi",
                         params={"db":"pubmed","id":",".join(ids),"retmode":"xml"},
                         headers=HEADERS, timeout=35)
        f.raise_for_status()
        root = ET.fromstring(f.text)
        for article in root.findall(".//PubmedArticle"):
            title = " ".join(article.findtext(".//ArticleTitle", default="").split())
            abstract = " ".join(" ".join(x.itertext()) for x in article.findall(".//Abstract/AbstractText"))
            authors = []
            for a in article.findall(".//Author"):
                collective = a.findtext("CollectiveName")
                last, fore = a.findtext("LastName"), a.findtext("ForeName")
                name = collective or " ".join(x for x in [last, fore] if x)
                if name: authors.append(name)
            journal = article.findtext(".//Journal/Title")
            year = article.findtext(".//PubDate/Year") or article.findtext(".//PubDate/MedlineDate", default="")[:4]
            doi = ""
            for aid in article.findall(".//ArticleId"):
                if aid.attrib.get("IdType") == "doi": doi = aid.text or ""
            pmid = article.findtext(".//PMID", default="")
            out.append({"title":title, "abstract":abstract, "authors":authors, "journal":journal,
                        "year":year, "doi":doi, "url":f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                        "source":"PubMed"})
    except Exception as e:
        out.append({"title":"PubMed search error", "abstract":str(e), "source":"error"})
    return out

def search_crossref(query, limit=15):
    """Search Crossref works metadata. Crossref records may not contain abstracts."""
    out = []
    try:
        r = requests.get("https://api.crossref.org/works",
                         params={"query.bibliographic":query,"rows":limit},
                         headers=HEADERS, timeout=25)
        r.raise_for_status()
        for item in r.json().get("message",{}).get("items",[]):
            title = (item.get("title") or [""])[0]
            authors = []
            for a in item.get("author",[]):
                name = " ".join(x for x in [a.get("family"),a.get("given")] if x)
                if name: authors.append(name)
            date = item.get("published-print") or item.get("published-online") or item.get("created") or {}
            parts = date.get("date-parts", [[None]])
            year = str(parts[0][0]) if parts and parts[0] and parts[0][0] else ""
            abstract = item.get("abstract","")
            # Crossref abstracts are often absent and may contain JATS markup.
            abstract = abstract.replace("<jats:p>"," ").replace("</jats:p>"," ")
            doi = item.get("DOI","")
            out.append({"title":title,"abstract":abstract,"authors":authors,
                        "journal":(item.get("container-title") or [""])[0],
                        "year":year,"doi":doi,"url":item.get("URL",""),"source":"Crossref"})
    except Exception as e:
        out.append({"title":"Crossref search error", "abstract":str(e), "source":"error"})
    return out

def verify_doi(doi):
    try:
        r = requests.get(f"https://api.crossref.org/works/{doi}",
                         headers=HEADERS, timeout=15)
        if r.status_code == 200:
            m = r.json().get("message",{})
            return True, f"Crossref record found: {(m.get('title') or [''])[0]}"
        return False, f"Crossref returned HTTP {r.status_code}; check DOI manually."
    except Exception as e:
        return False, f"Could not verify online: {e}"
